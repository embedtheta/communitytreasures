<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class My_uri_class{
    public $CI ;
    public function __construct() {
        //$this->CI =& get_instance();
    }
    
    public function uriRedirect(){
       /*$class = $this->CI->router->fetch_class();
       $method = $this->CI->router->fetch_method();
       //http://www.londoncitymodels.com/sitemap/index/
       if($class == "sitemap" && $method == "index"){
           redirect(base_url().$class);
       }*/
    }
    
}